<div class="field">
	<label>E-mail adres</label>
	<input type="text" name="email">
</div>

<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
