@extends('template.theme')

@section('scripts')
<script type="text/javascript">
$(document).ready(function() {
	logintest();
});
</script>
@stop