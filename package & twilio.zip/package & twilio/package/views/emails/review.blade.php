Beste {{ $company->name }},<br /><br />

Gebruiker {{ $user->name }}  heeft een review geplaatst voor uw bedrijf.  <br />
U kunt via het <a href="{{ url('admin/reviews/'.$company->id) }}">controle paneel</a> aangeven of u deze review op uw pagina wil plaatsen.<br /><br />

Met vriendelijke groet,<br />
Uwvoordeelpas.nl