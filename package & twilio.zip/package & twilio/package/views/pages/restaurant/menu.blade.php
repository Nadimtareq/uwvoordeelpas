<div id="topMenu" class="ui top attached tabular menu">
 	<a class="item" data-tab="first">Over ons  &nbsp;<i class="building icon"></i></a>
	<a class="item active" data-tab="second">Menu &nbsp;<i class="food icon"></i></a>
 	<a class="item" data-tab="thirds">Details  &nbsp;<i class="list icon"></i></a>
 	<a class="item" data-tab="four">Contact &nbsp;<i class="envelope icon"></i></a>
 	<a class="item" data-tab="five">Nieuws &nbsp;<i class="icon newspaper"></i></a>
 	<a class="item" data-tab="six">Groepen &nbsp;<i class="users icon"></i></a>
</div>