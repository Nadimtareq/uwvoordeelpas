<h5 class="ui header thin">
	<i class="icon food"></i>
	<div class="content">Over {{ $company->name }}</div>
</h5>

{!! $company->about_us !!}