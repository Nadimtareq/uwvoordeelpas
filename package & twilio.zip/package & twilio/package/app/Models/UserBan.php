<?php
namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class UserBan extends Model
{
    protected $table = 'users_bans';
}