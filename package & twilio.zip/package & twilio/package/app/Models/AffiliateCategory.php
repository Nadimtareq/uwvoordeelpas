<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateCategory extends Model
{

    protected $table = 'affiliates_categories';
    
    protected $guarded = array();

}
