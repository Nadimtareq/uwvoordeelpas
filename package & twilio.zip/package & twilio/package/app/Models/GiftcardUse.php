<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GiftcardUse extends Model
{

    protected $table = 'giftcard_use';

}