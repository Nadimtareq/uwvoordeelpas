<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyClick extends Model
{

    protected $table = 'companies_clicks';

}