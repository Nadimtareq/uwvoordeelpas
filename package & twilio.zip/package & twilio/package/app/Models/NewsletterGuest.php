<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewsletterGuest extends Model
{

    protected $table = 'newsletters_guests';

}