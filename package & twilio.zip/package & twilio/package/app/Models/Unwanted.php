<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Unwanted extends Model
{
    //
    protected $table = 'unwanted_word';
}
