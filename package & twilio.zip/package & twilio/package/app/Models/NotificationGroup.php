<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationGroup extends Model
{

    protected $table = 'alert_notifications_Groups';
    
    protected $guarded = array();


}
