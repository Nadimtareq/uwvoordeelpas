<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Request;


require_once '../Twilio/autoload.php';
use Twilio\Rest\Client;
use Twilio\Twiml;


class HomeController extends Controller
{


    /**
     * Create a new controller instance.
     *
     * @return void
     */


    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    public function send_sms(){

    $sid = 'ACefca5b03d9b63fab47891206984cd7a6';
    $token = '678178d623cb44a3cb21596bb434df35';
    $client = new Client($sid, $token);

    $message = Input::get('msg');
    $to_phno=Input::get('phone');
    $country_code = Input::get('c_code');
    $from_phno='+12568264404';

    $client->messages->create($country_code.$to_phno,array('from' => $from_phno,'body' => $message));

    echo $message;

    }
    public function push_sms(){
        echo "pushing sms";
    }
    public function call_no(){

    $sid = 'ACefca5b03d9b63fab47891206984cd7a6';
    $token = '678178d623cb44a3cb21596bb434df35';
    $client = new Client($sid, $token);

    $to_phno=Input::get('phone');
    $country_code = Input::get('c_code');
    $from_phno='+12568264404';

    $call = $client->calls->create(
    $country_code.$to_phno, "+12568264404",
    
      array("url" => "https://willing-turn-4104.twil.io/facts")//voice message
    );

    // return a JSON response
    return array('message' => 'Call incoming!');

    }

    public function say_message()
    {
        $response = new Twiml();
        $response->say('Hello Zaman.', ['voice' => 'alice', 'language' => 'en-IN',
        'loop' => 2]);

        echo $response;
    }
}
