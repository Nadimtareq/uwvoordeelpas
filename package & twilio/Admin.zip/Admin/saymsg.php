<?php

header('content-type: text/xml');
echo "<?xml version='1.0' encoding='UTF-8'?>";

?>

<Response>
<say>Hello Zaman</say>https://handler.twilio.com/twiml/EH037230c3e6154e5e0bf599782c525e3b
</Response>